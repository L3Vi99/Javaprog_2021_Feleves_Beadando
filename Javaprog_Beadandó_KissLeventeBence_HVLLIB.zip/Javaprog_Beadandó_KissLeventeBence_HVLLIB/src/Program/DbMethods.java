package Program;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.stream.Stream;

import javax.swing.JOptionPane;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.parser.Path;
import com.itextpdf.text.pdf.parser.clipper.Paths;

public class DbMethods {
	private Statement s = null;
	private Connection conn = null;
	private ResultSet rs = null;
	private PreparedStatement ps = null;
	private Formatter x;
	private Checker c = new Checker();

	// Kapcsol�d�s
	public void Connect() {
		try {
			String url = "jdbc:sqlite:src/beadandodb.db";
			conn = DriverManager.getConnection(url);
		} catch (SQLException e) {
			SM("JDBC Connect: " + e.getMessage());
		}
	}

	// Lekapcsol�d�s
	public void DisConnect() {
		try {
			conn.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Driver Regiszt�r�l�s gombhoz
	public void Reg() {
		try {
			Class.forName("org.sqlite.JDBC");
			SM("Sikeres driver regisztr�ci�!");
		} catch (ClassNotFoundException e) {
			SM("Hib�s driver regisztr�ci�!" + e.getMessage());
		}
	}

	// Driver Regiszt�r�l�s
	public void Reg1() {
		try {
			Class.forName("org.sqlite.JDBC");
		} catch (ClassNotFoundException e) {
			SM("Hib�s driver regisztr�ci�!" + e.getMessage());
		}
	}

	// �zenet ki�rat�
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}

	// Bejelentkez�s
	public int Login(String name, String pswd) {
		Connect();
		int pc = -1;
		String sql = "select count(*) pc from Users where name='" + name + "' and pswd='" + pswd + "';";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				pc = rs.getInt("pc");
			}
			rs.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
		DisConnect();
		return pc;
	}

	// Tagok kiolvas�sa
	public TagTM ReadAllDataTag() {
		Object tagtmn[] = { "Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�" };
		TagTM ttm = new TagTM(tagtmn, 0);
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0;
		String sql = "Select * from Tagok";
		Connect();
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				ttm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		DisConnect();
		return ttm;
	}

	// K�nyvek kiolvas�sa
	public KonyvTM ReadAllDataKonyv() {
		Object konyvtmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van" };
		KonyvTM ktm = new KonyvTM(konyvtmn, 0);
		String cim = "", szerzo = "", mdatum = "";
		int kid = 0, tid = 0;
		String sql = "Select * from K�nyv";
		Connect();
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				ktm.addRow(new Object[] { false, kid, cim, szerzo, mdatum, tid });
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		DisConnect();
		return ktm;
	}

	// Tagok t�rl�se
	public void DeleteTag(String tid) {
		String sql = "delete from Tagok where tid=" + tid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}

	// K�nyv t�rl�se
	public void DeleteKonyv(String kid) {
		String sql = "delete from K�nyv where kid=" + kid;
		try {
			s = conn.createStatement();
			s.execute(sql);
		} catch (Exception e) {
			SM("JDBC delete: " + e.getMessage());
		}
	}

	// Tagok modos�t�sa
	public void UpdateTag(String tid, String nev, String telszm, String cim, String sz�lido) {
		Connect();
		String sql = "update Tagok set nev= '" + nev + "', telszm= '" + telszm + "', cim= '" + cim + "', sz�lido= '"
				+ sz�lido + "' where tid='" + tid + "'";
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Sikeres m�dos�t�s!");
		} catch (Exception e) {
			SM("JDBC Udpate: " + e.getMessage());
		}
		DisConnect();
	}

	// K�nyv modos�t�sa
	public void UpdateKonyv(String kid, String cim, String szerzo, String mdatum, String tid) {
		Connect();
		String sql = "update K�nyv set cim= '" + cim + "', szerzo= '" + szerzo + "', mdatum= '" + mdatum + "', tid= '"
				+ tid + "' where kid='" + kid + "'";
		try {
			s = conn.createStatement();
			s.execute(sql);
			SM("Sikeres m�dos�t�s!");
		} catch (Exception e) {
			SM("JDBC Udpate: " + e.getMessage());
		}
		DisConnect();
	}

	// F�jl megnyit�sa
	public void openFile(String txtName) {
		try {
			x = new Formatter(txtName);
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}

	// F�jl Bez�r�sa
	public void closeFile() {
		x.close();
	}

	// Tagok.txt felt�lt�se
	public void addRecordsTag() {
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0;
		String sql = "Select * from Tagok";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				x.format(tid + ";" + nev + ";" + telszm + ";" + cim + ";" + sz�lido + "\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Tagok bet�lt�se txt-b�l
	public void ReplaceDataTag(String file) {
		String sql = "";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf = in.readLine();
			while (sf != null) {
				String[] st = sf.split(";");
				sql = "replace into Tagok values(" + st[0] + ", '" + st[1] + "', '" + st[2] + "', '" + st[3] + "', '"
						+ st[4] + "')";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok bet�ltve!");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: " + e.getMessage());
		}
	}

	// Konyvek.txt felt�lt�se
	public void addRecordsKonyv() {
		String cim = "", szerzo = "", mdatum = "";
		int kid = 0, tid = 0;
		String sql = "Select * from K�nyv";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				x.format(kid + ";" + cim + ";" + szerzo + ";" + mdatum + ";" + tid + "\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Konyvek bet�lt�se txt-b�l
	public void ReplaceDataKonyv(String file) {
		String sql = "";
		Connect();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String sf = in.readLine();
			sf = in.readLine();
			while (sf != null) {
				String[] st = sf.split(";");
				sql = "replace into K�nyv values(" + st[0] + ", '" + st[1] + "', '" + st[2] + "', '" + st[3] + "', '"
						+ st[4] + "')";
				s = conn.createStatement();
				s.execute(sql);
				sf = in.readLine();
			}
			in.close();
			SM("Adatok bet�ltve!");
		} catch (IOException | SQLException e) {
			SM("ReplaceData: " + e.getMessage());
		}
	}

	// Tagok k�djai a leg�rd�l� ablakokhoz
	public ArrayList<String> readtid() {
		String sql = "Select tid from Tagok";
		ArrayList<String> tidStr = new ArrayList<String>();
		tidStr.add("V�lassz!");
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tidStr.add(rs.getString("tid"));
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return tidStr;
	}

	public AllTM ReadAllData() {
		Object alltmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjel. D�tum", "Tag ID", "N�v", "Telefonsz�m", "C�m",
				"Sz�l. id�" };
		AllTM atm = new AllTM(alltmn, 0);
		String nev = "", telszm = "", tcim = "", sz�lido = "";
		int tid = 0;
		String szerzo = "", mdatum = "", kcim = "";
		int kid = 0;
		Connect();
		String sql = "Select * from K�nyv k left join Tagok t on k.tid = t.tid";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				kcim = rs.getString(2);
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt(5);
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				tcim = rs.getString(9);
				sz�lido = rs.getString("sz�lido");
				atm.addRow(new Object[] { false, kid, kcim, szerzo, mdatum, tid, nev, telszm, tcim, sz�lido });
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		DisConnect();
		return atm;
	}

	// T�bl�k nev�nek lek�r�se
	public void getTables() {
		Connect();
		try {
			int i = 1;
			DatabaseMetaData metaData = conn.getMetaData();
			String[] types = { "TABLE" };
			ResultSet tables = metaData.getTables(null, null, "%", types);
			while (tables.next()) {
				SM(i + ". t�bla neve: " + tables.getString("TABLE_NAME"));
				i++;
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
		DisConnect();
	}

	// TAg felv�tel
	public void InsertTag(String tid, String nev, String telszm, String cim, String sz�lido) {
		Connect();
		String sql = "insert into Tagok values (" + tid + ", '" + nev + "', '" + telszm + "', '" + cim + "', '"
				+ sz�lido + "')";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: " + e.getMessage());
		}
		DisConnect();
	}

	// K�nyv felv�tel
	public void InsertKonyv(String kid, String cim, String szerzo, String mdatum, String tid) {
		Connect();
		String sql = "insert into K�nyv values (" + kid + ", '" + cim + "', '" + szerzo + "', '" + mdatum + "', " + tid
				+ ")";
		try {
			s = conn.createStatement();
			s.executeUpdate(sql);
			SM("Insert OK!");
		} catch (SQLException e) {
			SM("JDBC insert: " + e.getMessage());
		}
		DisConnect();
	}

	// �sszevont.txt felt�lt�se
	public void addRecordsAll() {
		String nev = "", telszm = "", tcim = "", sz�lido = "";
		int tid = 0;
		String szerzo = "", mdatum = "", kcim = "";
		int kid = 0;
		Connect();
		String sql = "Select * from K�nyv k left join Tagok t on k.tid = t.tid";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				kcim = rs.getString(2);
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt(5);
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				tcim = rs.getString(9);
				sz�lido = rs.getString("sz�lido");
				x.format(kid + ";" + kcim + ";" + szerzo + ";" + mdatum + ";" + tid + ";" + nev + ";" + telszm + ";"
						+ tcim + ";" + sz�lido + "\n");
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
	}

	// Sz�r�1
	public Szuro1TM ReadDataSzuro1(String varos) {
		Object sz1tmn[] = { "Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�" };
		Szuro1TM sz1tm = new Szuro1TM(sz1tmn, 0);
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0, db = 0;
		String sql = "Select * from Tagok where cim like '" + varos + "%" + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				sz1tm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			tid = 0;
			nev = "Hib�s adat";
			telszm = "";
			cim = "";
			sz�lido = "";
			sz1tm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
		}
		return sz1tm;
	}

	// Sz�r�2
	public Szuro2TM ReadDataSzuro2(String alsohatar, String felsohatar) {
		Object sz2tmn[] = { "Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�" };
		Szuro2TM sz2tm = new Szuro2TM(sz2tmn, 0);
		String nev = "", telszm = "", cim = "", sz�lido = "";
		int tid = 0, db = 0;
		String sql = "Select * from Tagok where sz�lido between '" + alsohatar + "' and '" + felsohatar + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				tid = rs.getInt("tid");
				nev = rs.getString("nev");
				telszm = rs.getString("telszm");
				cim = rs.getString("cim");
				sz�lido = rs.getString("sz�lido");
				sz2tm.addRow(new Object[] { false, tid, nev, telszm, cim, sz�lido });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		return sz2tm;
	}

	// Sz�r�3
	public Szuro3TM ReadDataSzuro3(String szerzo) {
		Object sz3tmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van" };
		Szuro3TM sz3tm = new Szuro3TM(sz3tmn, 0);
		String cim = "", szerz = "", mdatum = "";
		int kid = 0, tid = 0, db = 0;
		String sql = "Select * from K�nyv where szerzo like '" + szerzo + "%" + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerz = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				sz3tm.addRow(new Object[] { false, kid, cim, szerz, mdatum, tid });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			kid = 0;
			cim = "";
			szerz = "Hib�s adat";
			mdatum = "";
			tid = 0;
			sz3tm.addRow(new Object[] { false, kid, cim, szerz, mdatum, tid });
		}
		return sz3tm;
	}

	// Sz�r�4
	public Szuro4TM ReadDataSzuro4(String alsohatar, String felsohatar) {
		Object sz4tmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van" };
		Szuro4TM sz4tm = new Szuro4TM(sz4tmn, 0);
		String cim = "", szerzo = "", mdatum = "";
		int kid = 0, tid = 0, db = 0;
		String sql = "Select * from K�nyv where mdatum between '" + alsohatar + "' and '" + felsohatar + "'";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sql);
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				mdatum = rs.getString("mdatum");
				tid = rs.getInt("tid");
				sz4tm.addRow(new Object[] { false, kid, cim, szerzo, mdatum, tid });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			kid = 0;
			cim = "";
			szerzo = "";
			mdatum = "Hib�s adat";
			tid = 0;
			sz4tm.addRow(new Object[] { false, kid, cim, szerzo, mdatum, tid });
		}
		return sz4tm;
	}

	// Sz�r�5
	public Szuro5TM ReadDataSzuro5(String tagnev) {
		Object sz5tmn[] = { "Jel", "K�d", "C�m", "Szerz�" };
		Szuro5TM sz5tm = new Szuro5TM(sz5tmn, 0);
		String cim = "", szerzo = "";
		int kid = 0, db = 0;
		String sql = "Select kid, k.cim, szerzo from K�nyv k inner join Tagok t on t.tid=k.tid where t.nev = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, tagnev);
			rs = ps.executeQuery();
			while (rs.next()) {
				kid = rs.getInt("kid");
				cim = rs.getString("cim");
				szerzo = rs.getString("szerzo");
				sz5tm.addRow(new Object[] { false, kid, cim, szerzo });
				db++;
			}
			rs.close();
		} catch (SQLException e) {
			SM(e.getMessage());
		}
		if (db == 0) {
			kid = 0;
			cim = "";
			szerzo = "Hib�s adat";
			sz5tm.addRow(new Object[] { false, kid, cim, szerzo });
		}

		return sz5tm;
	}
	
	// CSV Tagok olvas�sa
	public TagTM CsvReaderTag() {
		Object tagtmn[] = { "Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�" };
		TagTM ttm = new TagTM(tagtmn, 0);
		try {
			BufferedReader in = new BufferedReader(new FileReader("Tagok.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				ttm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4]});
				s=in.readLine();
			}
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
		}
		return ttm;
	}
	
	// CSV K�nyvek olvas�sa
	public KonyvTM CsvReaderKonyv() {
		Object konyvtmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van" };
		KonyvTM ktm = new KonyvTM(konyvtmn, 0);;
		try {
			BufferedReader in = new BufferedReader(new FileReader("Konyvek.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				ktm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4]});
				s=in.readLine();
			}
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
			
		}
		return ktm;
	}
	
	// CSV Mind kett� olvas�sa
	public AllTM CSVReaderAll() {
		Object alltmn[] = { "Jel", "K�d", "C�m", "Szerz�", "Megjel. D�tum", "Tag ID", "N�v", "Telefonsz�m", "C�m","Sz�l. id�" };
AllTM atm = new AllTM(alltmn, 0);
		try {
			BufferedReader in1 = new BufferedReader(new FileReader("Tagok.csv"));
			String s1 = in1.readLine();
			BufferedReader in2 = new BufferedReader(new FileReader("Konyvek.csv"));
			String s2 = in2.readLine();
			while(s1!=null && s2!=null) {
				String[] st1 = s1.split(";");
				String[] st2 = s2.split(";");
				atm.addRow(new Object[] {false, st2[0], st2[1], st2[2], st2[3], st2[4], st1[1], st1[2], st1[3], st1[4]});
				s1=in1.readLine();
				s2=in2.readLine();
			}
		} catch (Exception e) {
			SM("CSVREeader: " + e.getMessage());
		}
		return atm;
	}
	
	// TXT �r�s konyv
	public void CSVWriteToTXTKonyv() {
		try {
			BufferedReader in = new BufferedReader(new FileReader("Konyvek.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				x.format(st[0]+";"+ st[1]+";"+ st[2]+";"+ st[3]+";"+ st[4]+"\n");
				s=in.readLine();
			}
			in.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	// TXT �r�s tag
	public void CSVWriteToTXTTag() {
		try {
			BufferedReader in = new BufferedReader(new FileReader("Tagok.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				x.format(st[0]+";"+ st[1]+";"+ st[2]+";"+ st[3]+";"+ st[4]+"\n");
				s=in.readLine();
			}
			in.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	//TXT bet�lt�s K�nyv
	public void CSVTxtKonyv(KonyvTM ktm) {
		String kid,cim,szerzo,mdatum,tid,x=";";
		try {
			BufferedReader in = new BufferedReader(new FileReader("Konyvek.txt"));
			PrintStream out = new PrintStream(new FileOutputStream("Konyvek.csv"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				kid=st[0];
				cim=st[1];
				szerzo=st[2];
				mdatum=st[3];
				tid=st[4];
				out.println(kid+x+cim+x+szerzo+x+mdatum+x+tid);
				s=in.readLine();
			}
			SM("Felvitel OK");
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	//TXT bet�lt�s Tag
	public void CSVTxtTag(TagTM ttm) {
		String tid,nev,telszm,cim,sz�lido,x=";";
		try {
			BufferedReader in = new BufferedReader(new FileReader("Tagok.txt"));
			PrintStream out = new PrintStream(new FileOutputStream("Tagok.csv"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				tid=st[0];
				nev=st[1];
				telszm=st[2];
				cim=st[3];
				sz�lido=st[4];
				out.println(tid+x+nev+x+telszm+x+cim+x+sz�lido);
				s=in.readLine();
			}
			SM("Felvitel OK");
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	//Konyv felvitel
	public void CSVInsertKonyv(String kid, String cim, String szerzo, String mdatum, String tid) {
		String x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("Konyvek.csv",true));
			out.println(kid+x+cim+x+szerzo+x+mdatum+x+tid);
			out.close();
			SM("Felvitel OK");
		} catch (IOException e) {
			SM("CsvWriter: " + e.getMessage());
		}
	}
	
	//Tag felvitel
	public void CSVInsertTag(String tid, String nev, String telszm, String cim, String sz�lido) {
		String x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("Tagok.csv",true));
			out.println(tid+x+nev+x+telszm+x+cim+x+sz�lido);
			out.close();
			SM("Felvitel OK");
		} catch (IOException e) {
			SM("CsvWriter: " + e.getMessage());
		}
	}
	
	//K�nyv t�rl�s
	public void CSVDelKonyv(KonyvTM ktm) {
		String x = ";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("Konyvek.csv"));
			for (int i = 0; i < ktm.getRowCount(); i++) {
				String kid=ktm.getValueAt(i, 1).toString();
				String cim=ktm.getValueAt(i, 2).toString();
				String szerzo=ktm.getValueAt(i, 3).toString();
				String mdatum=ktm.getValueAt(i, 4).toString();
				String tid=ktm.getValueAt(i, 5).toString();
				out.println(kid+x+cim+x+szerzo+x+mdatum+x+tid);
			}
			out.close();
		} catch (IOException e) {
			SM("Delete: "+e.getMessage());
		}
	}
	
	//Tag t�rl�s
	public void CSVDelTag(TagTM ttm) {
		String x = ";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("Tagok.csv"));
			for (int i = 0; i < ttm.getRowCount(); i++) {
				String tid=ttm.getValueAt(i, 1).toString();
				String nev=ttm.getValueAt(i, 2).toString();
				String telszm=ttm.getValueAt(i, 3).toString();
				String cim=ttm.getValueAt(i, 4).toString();
				String sz�lido=ttm.getValueAt(i, 5).toString();
				out.println(tid+x+nev+x+telszm+x+cim+x+sz�lido);
			}
			out.close();
		} catch (IOException e) {
			SM("Delete: "+e.getMessage());
		}
	}
	
	//Konyv modos�t�s
	public void CSVModKonyv(String kid, String cim, String szerzo, String mdatum, String tid,KonyvTM ktm, int jel) {
			if(c.filled(kid)) ktm.setValueAt(kid, jel, 1);
			if(c.filled(cim)) ktm.setValueAt(cim, jel, 2);
			if(c.filled(szerzo)) ktm.setValueAt(szerzo, jel, 3);
			if(c.filled(mdatum)) ktm.setValueAt(mdatum, jel, 4);
			if(c.filled(tid)) ktm.setValueAt(tid, jel, 5);
			this.CSVDelKonyv(ktm);
			
	}
	
	//Tag modos�t�s
	public void CSVModTag(String tid, String nev, String telszm, String cim, String sz�lido, TagTM ttm, int jel) {
		if(c.filled(tid)) ttm.setValueAt(tid, jel, 1);
		if(c.filled(nev)) ttm.setValueAt(nev, jel, 2);
		if(c.filled(telszm)) ttm.setValueAt(telszm, jel, 3);
		if(c.filled(cim)) ttm.setValueAt(cim, jel, 4);
		if(c.filled(sz�lido)) ttm.setValueAt(sz�lido, jel, 5);
		this.CSVDelTag(ttm);
	}
	
	
	//Konyv hibakeres�
	public ErrKonyvTM CSVsearchErrorsKonyv() {
		Object errkonyvtmn[] = {"Jel", "K�d", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van"};
		ErrKonyvTM ektm = new ErrKonyvTM(errkonyvtmn,0);
		try {
			int db=0;
			BufferedReader in = new BufferedReader(new FileReader("Konyvek.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				boolean ok = false;
				if(c.filled(st[0]) && c.filled(st[1]) && c.filled(st[2]) && c.filled(st[3]) && c.filled(st[4])&& c.goodDate(st[3]) && c.goodInt(st[4]))
						ok = true;
				if(!ok) {
					ektm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4]});
					db++;
				}
				s=in.readLine();
			}
			SM(db + " darab hib�t tal�tam a Konyvek.csv-ben");
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
			
		}
		return ektm;
	}
	
	//Tag hibakeres�
	public ErrTagTM CSVsearchErrorsTag() {
		Object errtagtmn[] = {"Jel", "K�d", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�"};
		ErrTagTM ettm = new ErrTagTM(errtagtmn,0);
		try {
			int db=0;
			BufferedReader in = new BufferedReader(new FileReader("Tagok.csv"));
			String s = in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				boolean ok = false;
				if(c.filled(st[0]) && c.filled(st[1]) && c.filled(st[2]) && c.filled(st[3]) && c.filled(st[4]) && c.goodDate(st[4]) && c.goodInt(st[0]) && c.goodNum(st[2]))
						ok = true;
				if(!ok) {
					ettm.addRow(new Object[] {false, st[0], st[1], st[2], st[3], st[4]});
					db++;
				}
				s=in.readLine();
			}
			SM(db + " darab hib�t tal�tam a Tagok.csv-ben");
			in.close();
		} catch (IOException e) {
			SM("CSVREeader: " + e.getMessage());
			
		}
		return ettm;
	}
	
	public void WriteToTXTErrKonyv(ErrKonyvTM ektm) {
		String kid,cim,szerzo,mdatum,tid,x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream(" KonyvekErr.txt"));
			for (int i = 0; i < ektm.getRowCount(); i++) {
				kid=ektm.getValueAt(i, 1).toString();
				cim=ektm.getValueAt(i, 2).toString();
				szerzo=ektm.getValueAt(i, 3).toString();
				mdatum=ektm.getValueAt(i, 4).toString();
				tid=ektm.getValueAt(i, 5).toString();
				out.println(kid+x+cim+x+szerzo+x+mdatum+x+tid);
			}
			out.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	public void WriteToTXTErrTag(ErrTagTM ettm) {
		String tid,nev,telszm,cim,sz�lido,x=";";
		try {
			PrintStream out = new PrintStream(new FileOutputStream("TagokErr.txt"));
			for (int i = 0; i < ettm.getRowCount(); i++) {
				tid=ettm.getValueAt(i, 1).toString();
				nev=ettm.getValueAt(i, 2).toString();
				telszm=ettm.getValueAt(i, 3).toString();
				cim=ettm.getValueAt(i, 4).toString();
				sz�lido=ettm.getValueAt(i, 5).toString();
				out.println(tid+x+nev+x+telszm+x+cim+x+sz�lido);
				
			}
			out.close();
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	//PDF l�trehoz�s
	public void DataWriteToPdf() {
		try {
			Rectangle pageSize = new Rectangle(1000, 720);
			Document document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream("Tagok_konyvek.pdf"));

			document.open();
			document.addTitle("Tagok �s K�nyvek");
			PdfPTable tag = new PdfPTable(5);
			addTableHeaderTag(tag);
			addRowsTag(tag);
			PdfPTable konyv = new PdfPTable(5);
			addTableHeaderKonyv(konyv);
			addRowsKonyv(konyv);
			
			document.add(tag);
			document.add(konyv);
			document.close();
			SM("Felvitel OK");
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	//PDF Tag t�bla hozz�ad�s
	private void addTableHeaderTag(PdfPTable table) {
	    Stream.of("K�d:", "N�v", "Telefonsz�m", "C�m", "Sz�let�si id�")
	      .forEach(columnTitle -> {
	        PdfPCell header = new PdfPCell();
	        header.setBackgroundColor(BaseColor.LIGHT_GRAY);
	        header.setBorderWidth(2);
	        header.setPhrase(new Phrase(columnTitle));
	        table.addCell(header);
	    });
	}
	
	//PDF Konyv t�bla hozz�ad�s
	private void addTableHeaderKonyv(PdfPTable table) {
	    Stream.of( "K�d:", "C�m", "Szerz�", "Megjelen�s D�tuma", "Tagok akin�l a k�nyv van")
	      .forEach(columnTitle -> {
	        PdfPCell header = new PdfPCell();
	        header.setBackgroundColor(BaseColor.LIGHT_GRAY);
	        header.setBorderWidth(2);
	        header.setPhrase(new Phrase(columnTitle));
	        table.addCell(header);
	    });
	}
	
	//PDF Konyv sorok hozz�ad�s
	private void addRowsKonyv(PdfPTable table) {
		String kod,cim,szerzo,mdatum,tid;
		try {
			BufferedReader in = new BufferedReader(new FileReader("Konyvek.txt"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				kod=st[0];
				cim=st[1];
				szerzo=st[2];
				mdatum=st[3];
				tid=st[4];
				table.addCell(kod);
				table.addCell(cim);
				table.addCell(szerzo);
				table.addCell(mdatum);
				table.addCell(tid);
				s=in.readLine();
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	
	//PDF Tag sorok hozz�ad�s
	private void addRowsTag(PdfPTable table) {
		String kod,nev,telszm,cim,sz�lido;
		try {
			BufferedReader in = new BufferedReader(new FileReader("Tagok.txt"));
			String s=in.readLine();
			while(s!=null) {
				String[] st = s.split(";");
				kod=st[0];
				nev=st[1];
				telszm=st[2];
				cim=st[3];
				sz�lido=st[4];
				table.addCell(kod);
				table.addCell(nev);
				table.addCell(telszm);
				table.addCell(cim);
				table.addCell(sz�lido);
				s=in.readLine();
			}
		} catch (Exception e) {
			SM(e.getMessage());
		}
	}
	

}
