package Program;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CSVKezeloProg extends JFrame {

	private JPanel contentPane;
	private KonyvTM ktm;
	private TagTM ttm;
	private AllTM atm;
	private ErrKonyvTM ektm;
	private ErrTagTM ettm;
	DbMethods dbm = new DbMethods();


	public CSVKezeloProg(ChooseType choosetype) {
		super("Men�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 625, 350);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAllList = new JButton("Minden List\u00E1z\u00E1sa");
		btnAllList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atm = dbm.CSVReaderAll();
				AllList al = new AllList(CSVKezeloProg.this, atm);
				al.setVisible(true);
			}
		});
		btnAllList.setForeground(Color.BLACK);
		btnAllList.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnAllList.setBackground(new Color(169, 169, 169));
		btnAllList.setBounds(43, 88, 166, 60);
		contentPane.add(btnAllList);
		
		JButton btnTagList = new JButton("Tagok List\u00E1z\u00E1sa");
		btnTagList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ttm = dbm.CsvReaderTag();
				TagList tl = new TagList(CSVKezeloProg.this, ttm);
				tl.setVisible(true);
			}
		});
		btnTagList.setForeground(Color.BLACK);
		btnTagList.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnTagList.setBackground(new Color(169, 169, 169));
		btnTagList.setBounds(224, 88, 166, 60);
		contentPane.add(btnTagList);
		
		JButton btnKonyvList = new JButton("K\u00F6nyvek List\u00E1z\u00E1sa");
		btnKonyvList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ktm = dbm.CsvReaderKonyv();
				KonyvList kl = new KonyvList(CSVKezeloProg.this, ktm);
				kl.setVisible(true);
			}
		});
		btnKonyvList.setForeground(Color.BLACK);
		btnKonyvList.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnKonyvList.setBackground(new Color(169, 169, 169));
		btnKonyvList.setBounds(400, 88, 166, 60);
		contentPane.add(btnKonyvList);
		
		JButton btnUjAdat = new JButton("\u00DAj Adat");
		btnUjAdat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewInsert ni = new NewInsert(CSVKezeloProg.this);
				ni.setVisible(true);
			}
		});
		btnUjAdat.setForeground(Color.BLACK);
		btnUjAdat.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnUjAdat.setBackground(new Color(169, 169, 169));
		btnUjAdat.setBounds(224, 158, 166, 60);
		contentPane.add(btnUjAdat);
		
		JButton btnAdatokKirsaPdfbe = new JButton("Adatok ki\u00EDr\u00E1sa\r\nPDF-be");
		btnAdatokKirsaPdfbe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.DataWriteToPdf();
			}
		});
		btnAdatokKirsaPdfbe.setForeground(Color.BLACK);
		btnAdatokKirsaPdfbe.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnAdatokKirsaPdfbe.setBackground(new Color(169, 169, 169));
		btnAdatokKirsaPdfbe.setBounds(10, 158, 199, 60);
		contentPane.add(btnAdatokKirsaPdfbe);
		
		JButton btnAdatokKirsaPdfbe_1 = new JButton("Hib\u00E1k keres\u00E9se");
		btnAdatokKirsaPdfbe_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ektm = dbm.CSVsearchErrorsKonyv();
				ettm = dbm.CSVsearchErrorsTag();
				ErrKonyvList esl = new ErrKonyvList(CSVKezeloProg.this, ektm);
				ErrTagList erl = new ErrTagList(CSVKezeloProg.this,ettm);
				if(ektm.getRowCount()>0)
					esl.setVisible(true);
				if(ettm.getRowCount()>0)
					erl.setVisible(true);
			}
		});
		btnAdatokKirsaPdfbe_1.setForeground(Color.BLACK);
		btnAdatokKirsaPdfbe_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnAdatokKirsaPdfbe_1.setBackground(new Color(169, 169, 169));
		btnAdatokKirsaPdfbe_1.setBounds(400, 158, 199, 60);
		contentPane.add(btnAdatokKirsaPdfbe_1);
		
		JLabel lblAdatbzisKezelMen = new JLabel("CSV Kezel\u0151 Men\u00FC");
		lblAdatbzisKezelMen.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblAdatbzisKezelMen.setForeground(new Color(192,192,192));				
			}
			public void mouseExited(MouseEvent e) {
				lblAdatbzisKezelMen.setForeground(new Color(0,0,0));
			}
		});
		lblAdatbzisKezelMen.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdatbzisKezelMen.setForeground(Color.BLACK);
		lblAdatbzisKezelMen.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblAdatbzisKezelMen.setBounds(137, 30, 344, 28);
		contentPane.add(lblAdatbzisKezelMen);
		
		JLabel lblNewLabel = new JLabel("Kil\u00E9p\u00E9s");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel.setForeground(new Color(255,0,0));
				
			}
			public void mouseExited(MouseEvent e) {
				lblNewLabel.setForeground(new Color(0,0,0));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				if(JOptionPane.showConfirmDialog(null, "Ezzel visszal�p a form�tum v�laszt�shoz. Biztos?", "Biztos?", JOptionPane.YES_NO_OPTION)==0) {
					ChooseType ct = new ChooseType(null);
					ct.setVisible(true);
					dispose();
				}
			}
		});
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblNewLabel.setBounds(269, 259, 74, 17);
		contentPane.add(lblNewLabel);
	}
}
