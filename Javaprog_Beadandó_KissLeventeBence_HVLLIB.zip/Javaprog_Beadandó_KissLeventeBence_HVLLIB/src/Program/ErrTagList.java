package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;

public class ErrTagList extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private ErrTagTM ettm;
	DbMethods dbm = new DbMethods();
	private Checker c = new Checker();
	
	
	public ErrTagList(JFrame f, ErrTagTM ett) {
		super(f,"Tag hib�k list�ja", true);
		setUndecorated(true);
		ettm = ett;
		setBounds(100, 100, 670, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JButton btnNewButton = new JButton("Bez\u00E1r");
		btnNewButton.setBackground(new Color(169, 169, 169));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose(); 
			}
		});
		btnNewButton.setBounds(575, 252, 85, 24);
		contentPanel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 650, 232);
		contentPanel.add(scrollPane);
		
		table = new JTable(ett);
		scrollPane.setViewportView(table);
		
		TableColumn tc = null;
		for (int i = 0; i < 6; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0 || i==1 ) tc.setPreferredWidth(20);
		else if (i==4) tc.setPreferredWidth(180);
		else {tc.setPreferredWidth(100);}
		}
		
		table.setAutoCreateRowSorter(true);
		
		JButton btnMents = new JButton("Ment\u00E9s");
		btnMents.setBackground(new Color(169, 169, 169));
		btnMents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dbm.openFile("TagokErr.txt");
					dbm.WriteToTXTErrTag(ettm);
					dbm.closeFile();
					SM("Sikeres ki�r�s! A file megtal�lhat� TagokErr.txt n�ven");
				} catch (Exception e2) {
					SM("Sikertelen k��r�s: "+e2.getMessage());
				}
			}
		});
		btnMents.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnMents.setBounds(10, 252, 85, 24);
		contentPanel.add(btnMents);
		
		JLabel lblNewLabel = new JLabel("Hib\u00E1s Tagok");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setBounds(278, 251, 137, 24);
		contentPanel.add(lblNewLabel);
		TableRowSorter<AllTM> trs = (TableRowSorter<AllTM>)table.getRowSorter();
		trs.setSortable(0, false);
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
}
