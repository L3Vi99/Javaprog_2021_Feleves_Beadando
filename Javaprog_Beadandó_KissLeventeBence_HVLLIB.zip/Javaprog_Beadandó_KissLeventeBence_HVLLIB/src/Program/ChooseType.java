package Program;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ChooseType extends JFrame {

	private JPanel contentPane;

	public ChooseType(Login login) {
		super("Form�tum v�laszt�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Milyen form\u00E1tumba szeretne dolgozni ? ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(52, 37, 326, 47);
		contentPane.add(lblNewLabel);
		
		String[] types = {"V�lassz!", "SQLite DB", "CSV"};
		JComboBox comboBox = new JComboBox(types);
		comboBox.setBackground(new Color(169, 169, 169));
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
		comboBox.setBounds(133, 87, 154, 28);
		contentPane.add(comboBox);
		
		JButton btnGo = new JButton("Start");
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tipus = RTF2(comboBox);
				if(tipus.equals("SQLite DB")) {
					ABKezeloProg abkezel = new ABKezeloProg(ChooseType.this);
					abkezel.setVisible(true);
					dispose();
				}
				else if(tipus.equals("CSV"))
				{
					CSVKezeloProg csvkezel = new CSVKezeloProg(ChooseType.this);
					csvkezel.setVisible(true);
					dispose();
				}
			}
		});
		btnGo.setBackground(new Color(169, 169, 169));
		btnGo.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnGo.setBounds(164, 136, 91, 37);
		contentPane.add(btnGo);
		
		JLabel lblNewLabel_1 = new JLabel("Kil\u00E9p\u00E9s");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_1.setForeground(new Color(255,0,0));
				
			}
			public void mouseExited(MouseEvent e) {
				lblNewLabel_1.setForeground(new Color(0,0,0));
			}
			public void mouseClicked(MouseEvent arg0) {
				if(JOptionPane.showConfirmDialog(null, "Biztos, hogy ki akar l�pni?", "Kil�p�s", JOptionPane.YES_NO_OPTION)==0) {
					System.exit(0);
				}
			}
		});
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblNewLabel_1.setBounds(338, 219, 74, 17);
		contentPane.add(lblNewLabel_1);
	}
	
	public String RTF2(JComboBox jcb) {
		String str = jcb.getSelectedItem().toString();
		return str;
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Hiba �zenet", 2);
	}
}
