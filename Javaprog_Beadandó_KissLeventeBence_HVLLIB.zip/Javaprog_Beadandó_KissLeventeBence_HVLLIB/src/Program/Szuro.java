package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;

public class Szuro extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField varos;
	private JTextField also1;
	private JTextField felso1;
	private JTextField szerzo;
	private JTextField also2;
	private JTextField felso2;
	private JLabel lblrjaBeEgy;
	private JTextField tagnev;
	private JButton btnNewButton;
	private JButton btnSzrs;
	private JButton btnSzrs_1;
	private JButton btnSzrs_2;
	private JButton btnSzrs_3;
	private JButton btnSzrs_4;
	DbMethods dbm = new DbMethods();
	private Szuro1TM sz1tm;
	private Szuro2TM sz2tm;
	private Szuro3TM sz3tm;
	private Szuro4TM sz4tm;
	private Szuro5TM sz5tm;

	public Szuro() {
		setTitle("Sz�r�");
		setBounds(100, 100, 800, 400);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(128, 128, 128));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u00CDrja be a v\u00E1ros nev\u00E9t \u00E9s meg kapja az ott \u00E9l\u0151 tagokat");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBackground(new Color(192, 192, 192));
		lblNewLabel.setBounds(10, 10, 386, 30);
		contentPanel.add(lblNewLabel);
		
		varos = new JTextField();
		varos.setHorizontalAlignment(SwingConstants.CENTER);
		varos.setBounds(117, 38, 177, 19);
		contentPanel.add(varos);
		varos.setColumns(10);
		
		JLabel lblAzokATagok = new JLabel("Azok a tagok akik                         \u00E9s                        k\u00F6z\u00F6tt sz\u00FCletek");
		lblAzokATagok.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAzokATagok.setBackground(Color.LIGHT_GRAY);
		lblAzokATagok.setBounds(10, 67, 450, 30);
		contentPanel.add(lblAzokATagok);
		
		also1 = new JTextField();
		also1.setBounds(139, 74, 77, 19);
		contentPanel.add(also1);
		also1.setColumns(10);
		
		felso1 = new JTextField();
		felso1.setColumns(10);
		felso1.setBounds(247, 74, 77, 19);
		contentPanel.add(felso1);
		
		JLabel lblrjaBeA = new JLabel("\u00CDrja be a szerz\u0151 nev\u00E9t \u00E9s meg kapja az \u00E1ltala \u00EDrt k\u00F6nyveket");
		lblrjaBeA.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblrjaBeA.setBackground(Color.LIGHT_GRAY);
		lblrjaBeA.setBounds(10, 107, 391, 30);
		contentPanel.add(lblrjaBeA);
		
		JLabel lblAzokAKnyvek = new JLabel("Azok a k\u00F6nyvek aminek a megjelen\u00E9si d\u00E1tuma                         \u00E9s                        k\u00F6z\u00F6tt van");
		lblAzokAKnyvek.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAzokAKnyvek.setBackground(Color.LIGHT_GRAY);
		lblAzokAKnyvek.setBounds(10, 164, 584, 30);
		contentPanel.add(lblAzokAKnyvek);
		
		szerzo = new JTextField();
		szerzo.setHorizontalAlignment(SwingConstants.CENTER);
		szerzo.setColumns(10);
		szerzo.setBounds(117, 135, 177, 19);
		contentPanel.add(szerzo);
		
		also2 = new JTextField();
		also2.setColumns(10);
		also2.setBounds(319, 171, 77, 19);
		contentPanel.add(also2);
		
		felso2 = new JTextField();
		felso2.setColumns(10);
		felso2.setBounds(430, 171, 77, 19);
		contentPanel.add(felso2);
		
		lblrjaBeEgy = new JLabel("\u00CDrja be egy tag nev\u00E9t \u00E9s meg kapja a n\u00E1la l\u00E9v\u0151 k\u00F6nyvet(eket)");
		lblrjaBeEgy.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblrjaBeEgy.setBackground(Color.LIGHT_GRAY);
		lblrjaBeEgy.setBounds(10, 204, 435, 30);
		contentPanel.add(lblrjaBeEgy);
		
		tagnev = new JTextField();
		tagnev.setHorizontalAlignment(SwingConstants.CENTER);
		tagnev.setColumns(10);
		tagnev.setBounds(117, 231, 177, 19);
		contentPanel.add(tagnev);
		
		btnNewButton = new JButton("Bez\u00E1r");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNewButton.setBackground(new Color(169, 169, 169));
		btnNewButton.setBounds(341, 302, 104, 30);
		contentPanel.add(btnNewButton);
		
		btnSzrs = new JButton("Sz\u0171r\u00E9s");
		btnSzrs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!filledTF(varos)) SM("�rjon be egy v�ros nevet!");
				else if(!goodString(varos)) SM("Ne sz�mokat adjon meg!");
				else {
					dbm.Connect();
					sz1tm = dbm.ReadDataSzuro1(RTF(varos));
					dbm.DisConnect();
					Szuro1List sz1 = new Szuro1List(Szuro.this,sz1tm);
					sz1.setVisible(true);
				}
			}
		});
		btnSzrs.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnSzrs.setBackground(new Color(169, 169, 169));
		btnSzrs.setBounds(370, 10, 104, 30);
		contentPanel.add(btnSzrs);
		
		btnSzrs_1 = new JButton("Sz\u0171r\u00E9s");
		btnSzrs_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!goodDate(also1) && !goodDate(felso1) ) SM("A d�tum helytelen");
				else {
					String alsohat = RTF(also1);
					String felsohat = RTF(felso1);
					dbm.Connect();
					sz2tm = dbm.ReadDataSzuro2(alsohat, felsohat);
					dbm.DisConnect();
					Szuro2List sz2 = new Szuro2List(Szuro.this,sz2tm);
					sz2.setVisible(true);	
				}
			}
		});
		btnSzrs_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnSzrs_1.setBackground(new Color(169, 169, 169));
		btnSzrs_1.setBounds(454, 67, 104, 30);
		contentPanel.add(btnSzrs_1);
		
		btnSzrs_2 = new JButton("Sz\u0171r\u00E9s");
		btnSzrs_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!filledTF(szerzo)) SM("�rjon be egy nevet!");
				else if(!goodString(szerzo)) SM("Ne sz�mokat adjon meg!");
				else {
					dbm.Connect();
					sz3tm = dbm.ReadDataSzuro3(RTF(szerzo));
					dbm.DisConnect();
					Szuro3List sz3 = new Szuro3List(Szuro.this,sz3tm);
					sz3.setVisible(true);
				}
			}
		});
		btnSzrs_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnSzrs_2.setBackground(new Color(169, 169, 169));
		btnSzrs_2.setBounds(403, 107, 104, 30);
		contentPanel.add(btnSzrs_2);
		
		btnSzrs_3 = new JButton("Sz\u0171r\u00E9s");
		btnSzrs_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!goodDate(also2) && !goodDate(felso2) ) SM("A d�tum helytelen");
				else{
				String alsohat = RTF(also2);
				String felsohat = RTF(felso2);
				dbm.Connect();
				sz4tm = dbm.ReadDataSzuro4(alsohat, felsohat);
				dbm.DisConnect();
				Szuro4List sz4 = new Szuro4List(Szuro.this,sz4tm);
				sz4.setVisible(true);
				}
			}
		});
		btnSzrs_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnSzrs_3.setBackground(new Color(169, 169, 169));
		btnSzrs_3.setBounds(597, 170, 104, 30);
		contentPanel.add(btnSzrs_3);
		
		btnSzrs_4 = new JButton("Sz\u0171r\u00E9s");
		btnSzrs_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Connect();
				sz5tm = dbm.ReadDataSzuro5(RTF(tagnev));
				dbm.DisConnect();
				Szuro5List sz5 = new Szuro5List(Szuro.this,sz5tm);
				sz5.setVisible(true);
			}
		});
		btnSzrs_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnSzrs_4.setBackground(new Color(169, 169, 169));
		btnSzrs_4.setBounds(419, 224, 104, 30);
		contentPanel.add(btnSzrs_4);
		
		Object sz1tmn[] = {"Jel","K�d","N�v","Telefonsz�m","C�m","Sz�let�si id�"};
		sz1tm = new Szuro1TM(sz1tmn, 0);
		
		Object sz2tmn[] = {"Jel","K�d","N�v","Telefonsz�m","C�m","Sz�let�si id�"};
		sz2tm = new Szuro2TM(sz2tmn, 0);
		
		Object sz3tmn[] = {"Jel","K�d","C�m","Szerz�","Megjelen�s D�tuma","Tag akin�l a k�nyv van"};
		sz3tm = new Szuro3TM(sz3tmn, 0);
		
		Object sz4tmn[] = {"Jel","K�d","C�m","Szerz�","Megjelen�s D�tuma","Tag akin�l a k�nyv van"};
		sz4tm = new Szuro4TM(sz4tmn, 0);
		
		Object sz5tmn[] = {"Jel","K�d","C�m","Szerz�"};
		sz5tm = new Szuro5TM(sz5tmn, 0);
		
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	public String RTF2(JTextField jtf2, JTextField jtf) {
		if(jtf2.getText().length()==0)
			return jtf.getText();
		return jtf2.getText();
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
	
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
	
	public boolean goodString(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return false;
		} catch (Exception e) {
			return true;
		}
	}
	
	public boolean goodDate(JTextField jtf) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {return false;}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}

}
