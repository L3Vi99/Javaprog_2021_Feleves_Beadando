package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;

public class ModKonyv extends JDialog {

	private final JPanel contentPanel = new JPanel();
	DbMethods dbm = new DbMethods();
	private JTextField kid;
	private JTextField cim;
	private JTextField szerzo;
	private JTextField mdatum;
	private JTextField tid;
	private JTextField cim2;
	private JTextField szerzo2;
	private JTextField mdatum2;
	private JComboBox tid2;
	private ArrayList<String> tidStr;
	DbMethods dbm1 = new DbMethods();
	private Checker c = new Checker();
	
	public ModKonyv(JDialog d, String bekid,String becim,String beszerzo,String bemdatum,String betid, int n, KonyvTM ktm, int jel) {
		super(d, "Adatok m�dos�t�sa", true);
		setBounds(100, 100, 470, 245);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(192, 192, 192));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("K\u00F3d:");
		lblNewLabel.setBounds(10, 10, 45, 13);
		contentPanel.add(lblNewLabel);
		
		JLabel lblNv = new JLabel("C\u00EDm:");
		lblNv.setBounds(10, 33, 45, 13);
		contentPanel.add(lblNv);
		
		JLabel lblTelefonszm = new JLabel("Szerz\u0151:");
		lblTelefonszm.setBounds(10, 56, 72, 13);
		contentPanel.add(lblTelefonszm);
		
		JLabel lblCm = new JLabel("Megjelen\u00E9s d\u00E1tuma :");
		lblCm.setBounds(10, 79, 106, 13);
		contentPanel.add(lblCm);
		
		JLabel lblSzletsiId = new JLabel("Tag ID:");
		lblSzletsiId.setBounds(10, 102, 72, 13);
		contentPanel.add(lblSzletsiId);
		
		kid = new JTextField(bekid);
		kid.setHorizontalAlignment(SwingConstants.CENTER);
		kid.setEditable(false);
		kid.setBounds(87, 7, 135, 19);
		contentPanel.add(kid);
		kid.setColumns(10);
		
		cim = new JTextField(becim);
		cim.setHorizontalAlignment(SwingConstants.CENTER);
		cim.setEditable(false);
		cim.setColumns(10);
		cim.setBounds(58, 30, 164, 19);
		contentPanel.add(cim);
		
		szerzo = new JTextField(beszerzo);
		szerzo.setHorizontalAlignment(SwingConstants.CENTER);
		szerzo.setEditable(false);
		szerzo.setColumns(10);
		szerzo.setBounds(58, 53, 164, 19);
		contentPanel.add(szerzo);
		
		mdatum = new JTextField(bemdatum);
		mdatum.setHorizontalAlignment(SwingConstants.CENTER);
		mdatum.setEditable(false);
		mdatum.setColumns(10);
		mdatum.setBounds(126, 76, 96, 19);
		contentPanel.add(mdatum);
		
		tid = new JTextField(betid);
		tid.setHorizontalAlignment(SwingConstants.CENTER);
		tid.setEditable(false);
		tid.setColumns(10);
		tid.setBounds(87, 99, 135, 19);
		contentPanel.add(tid);
		
		cim2 = new JTextField();
		cim2.setBounds(232, 30, 190, 19);
		contentPanel.add(cim2);
		cim2.setColumns(10);
		
		szerzo2 = new JTextField();
		szerzo2.setColumns(10);
		szerzo2.setBounds(232, 53, 190, 19);
		contentPanel.add(szerzo2);
		
		mdatum2 = new JTextField();
		mdatum2.setColumns(10);
		mdatum2.setBounds(232, 76, 190, 19);
		contentPanel.add(mdatum2);
		
		JButton btnNewButton = new JButton("M\u00F3dos\u00EDt");
		btnNewButton.setBackground(new Color(169, 169, 169));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(n==0) {
					dbm.Connect();
					if(!goodDate(mdatum2)) SM("A d�tum helytelen");
					else{
					dbm.UpdateKonyv(RTF(kid), RTF2(cim2,cim), RTF2(szerzo2,szerzo), RTF2(mdatum2,mdatum), RTF3(tid2,tid));
					dbm.DisConnect();
					}
				}
				else if(n==1) {
					if(modDataPc()>0) {
						dbm.CSVModKonyv(RTF(kid), RTF2(cim2,cim), RTF2(szerzo2,szerzo), RTF2(mdatum2,mdatum), RTF3(tid2,tid), ktm, jel);
						dispose();
					}
				}
			}
		});
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(167, 140, 107, 39);
		contentPanel.add(btnNewButton);
		
		dbm1.Connect();
		tidStr = dbm1.readtid();
		dbm1.DisConnect();
		
		Object[] real = tidStr.toArray();
		tid2 = new JComboBox(real);
		tid2.setBounds(232, 98, 190, 21);
		contentPanel.add(tid2);

	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	
	public String RTF2(JTextField jtf2, JTextField jtf) {
		if(jtf2.getText().length()==0)
			return jtf.getText();
		return jtf2.getText();
	}
	
	public String RTF3(JComboBox jcb, JTextField jtf) {
		if(jcb.getSelectedItem().toString().equals("V�lassz!"))
			return jtf.getText();
		return jcb.getSelectedItem().toString();
	}
	
	public boolean goodDate(JTextField jtf) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {return false;}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Hiba �zenet", 2);
	}
	
	public int modDataPc() {
		int pc = 0;
		if(c.filled(kid)) pc++;
		if(c.filled(cim2)) pc++;
		if(c.filled(szerzo2)) pc++;
		if(c.filled(mdatum2)) pc++;
		if(c.filled(tid)) pc++;
		return pc;
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
		
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}
