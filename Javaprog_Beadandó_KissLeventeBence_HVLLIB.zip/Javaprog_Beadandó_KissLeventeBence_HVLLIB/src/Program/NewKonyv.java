package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.util.Date;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewKonyv extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField kid;
	private JTextField cim;
	private JTextField szerzo;
	private JTextField mdatum;
	private JTextField tid;
	DbMethods dbm = new DbMethods();
	private Checker c = new Checker();

	public NewKonyv(JFrame f, int n) {
		super(f,"�j k�nyv felv�tele", true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(192, 192, 192));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("K\u00F3d:");
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblNewLabel.setBounds(10, 10, 122, 26);
			contentPanel.add(lblNewLabel);
		}
		{
			JLabel lblNv = new JLabel("C\u00EDm:");
			lblNv.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblNv.setBounds(10, 46, 122, 26);
			contentPanel.add(lblNv);
		}
		{
			JLabel lblTelefonszm = new JLabel("Szerz\u0151:");
			lblTelefonszm.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblTelefonszm.setBounds(10, 82, 122, 26);
			contentPanel.add(lblTelefonszm);
		}
		{
			JLabel lblCm = new JLabel("Megjelen\u00E9s d\u00E1tuma:");
			lblCm.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblCm.setBounds(10, 118, 137, 26);
			contentPanel.add(lblCm);
		}
		{
			JLabel lblSzletsiId = new JLabel("Tag sz\u00E1ma:");
			lblSzletsiId.setFont(new Font("Tahoma", Font.PLAIN, 14));
			lblSzletsiId.setBounds(10, 154, 122, 26);
			contentPanel.add(lblSzletsiId);
		}
		{
			kid = new JTextField();
			kid.setBounds(60, 13, 107, 25);
			contentPanel.add(kid);
			kid.setColumns(10);
		}
		{
			cim = new JTextField();
			cim.setColumns(10);
			cim.setBounds(60, 46, 233, 25);
			contentPanel.add(cim);
		}
		{
			szerzo = new JTextField();
			szerzo.setColumns(10);
			szerzo.setBounds(83, 82, 233, 25);
			contentPanel.add(szerzo);
		}
		{
			mdatum = new JTextField();
			mdatum.setColumns(10);
			mdatum.setBounds(157, 121, 107, 25);
			contentPanel.add(mdatum);
		}
		{
			JButton btnNewButton = new JButton("Felv\u00E9tel");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(n==0) {
					if(!filledTF(kid)) SM("A k�d mez� �res");
					else if(!goodInt(kid)) SM("A k�d mez� nem helyes");
					else if(!filledTF(cim)) SM("A c�m mez� �res");
					else if(!filledTF(szerzo)) SM("A szerz� mez� �res");
					else if(!filledTF(mdatum)) SM("A d�tum mez� �res");
					else if(!goodDate(mdatum)) SM("A d�tum helytelen");
					else if(!filledTF(tid)) SM("A tag k�d mez�je �res");
					else if(!goodInt(tid)) SM("A tag k�d mez� nem helyes");
					else {
						dbm.InsertTag(RTF(kid), RTF(cim), RTF(szerzo), RTF(mdatum), RTF(tid));
						dispose();
					}
					}
					else if(n==1) {
						if(c.filled(kid, "K�d"))
							if(c.goodInt(kid, "K�d"))
								if(c.filled(cim, "C�m"))
									if(c.filled(szerzo, "Szerz�"))
										if(c.filled(mdatum, "Megjelen�si d�tum"))
											if(c.goodDate(mdatum, "Megjelen�si d�tum"))
												if(c.filled(tid, "Tag sz�ma"))
													if(c.goodInt(tid, "Tag sz�ma"))
															dbm.CSVInsertKonyv(RTF(kid), RTF(cim), RTF(szerzo), RTF(mdatum), RTF(tid));
					}
					
				}
			});
			btnNewButton.setBackground(new Color(169, 169, 169));
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnNewButton.setBounds(245, 199, 130, 40);
			contentPanel.add(btnNewButton);
		}
		{
			tid = new JTextField();
			tid.setColumns(10);
			tid.setBounds(103, 157, 107, 25);
			contentPanel.add(tid);
		}
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Hiba �zenet", 2);
	}
	
	public String RTF(JTextField jtf) {
		return jtf.getText();
	}
	
	public boolean filledTF(JTextField jtf) {
		String s = RTF(jtf);
		if(s.length()>0) return true;
		return false;
	}
	
	public boolean goodDate(JTextField jtf) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {return false;}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public boolean goodInt(JTextField jtf) {
		String s = RTF(jtf);
		try {
			Integer.parseInt(s); return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

}
