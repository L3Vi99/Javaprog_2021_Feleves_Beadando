package Program;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Checker {

	public boolean filled(JTextField a, String an) {
		String s = RTF(a);
		if (s.length() > 0)
			return true;
		else {
			SM("Hiba: a(z) " + an + " mez� �res!", 0);
			return false;
		}
	}

	public boolean filled(JTextField a) {
		String s = RTF(a);
		if (s.length() > 0)
			return true;
		else
			return false;
	}

	public boolean filled(String a) {
		if (a.length() > 0)
			return true;
		else
			return false;
	}

	public boolean goodNum(String a) {
		if (a.length() > 0 && a.length() < 13)
			return true;
		else
			return false;
	}
	
	public boolean goodPhone(JTextField jtf, String an) {
		String s = RTF(jtf);
		boolean b = true;
		if ((s.length()) == 11) {			
			try {
				Long.parseLong(s);
			} catch (NumberFormatException e) {
				SM("A(z) " + an + " mez�ben hib�s adat van", 0);
				b = false;
			}
		}
		else {
			SM("A(z) " + an + " mez�ben hib�s adat van", 0);
			b = false;
		}
		return b;
			
	}
	

	public boolean goodInt(JTextField a, String an) {
		String s = RTF(a);
		boolean b = filled(a,an);
		if(b) try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			SM("A(z) "+an+" mez�ben hib�s a sz�madat!", 0);
			b=false;
		}
		return b;
	}
	
	public boolean goodInt(String s, String an) {
		boolean b = true;
		try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			SM("A(z) "+an+" mez�ben hib�s a sz�madat!", 0);
			b=false;
		}
		return b;
	}
	
	public boolean goodInt(String s) {
		boolean b = true;
		try {
			Integer.parseInt(s);
		} catch (NumberFormatException e) {
			b=false;
		}
		return b;
	}
	
	public boolean goodDate(JTextField jtf, String an) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = RTF(jtf);
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {
			SM("A(z) "+an+" mez�ben hib�s d�tum van",0);
			return false;
		}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public boolean goodDate(String s, String an) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {
			SM("A(z) "+an+" mez�ben hib�s d�tum van",0);
			return false;
		}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}
	
	public boolean goodDate(String s) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		Date testDate = null;
		try {
			testDate = sdf.parse(s);
		} catch (ParseException e) {
			return false;
		}
		if(sdf.format(testDate).equals(s)) return true;
		else return false;
	}

	public String RTF(JTextField jtf) {
		return jtf.getText();
	}

	public void SM(String msg, int tipus) {
		JOptionPane.showMessageDialog(null, msg, "Program �zenet", tipus);
	}
}
