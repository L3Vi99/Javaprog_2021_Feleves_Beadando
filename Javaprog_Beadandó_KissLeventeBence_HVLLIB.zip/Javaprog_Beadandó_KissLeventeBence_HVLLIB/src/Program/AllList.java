package Program;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class AllList extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private AllTM atm;
	DbMethods dbm = new DbMethods();
	
	
	public AllList(JFrame f, AllTM betm) {
		super(f,"�sszevont lista", true);
		atm = betm;
		setBounds(100, 100, 1100, 320);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JButton btnNewButton = new JButton("Bez\u00E1r");
		btnNewButton.setBackground(new Color(169, 169, 169));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose(); 
			}
		});
		btnNewButton.setBounds(549, 252, 85, 24);
		contentPanel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 1066, 232);
		contentPanel.add(scrollPane);
		
		table = new JTable(atm);
		scrollPane.setViewportView(table);
		
		TableColumn tc = null;
		for (int i = 0; i < 10; i++) {
		tc = table.getColumnModel().getColumn(i);
		if (i==0 || i==1|| i==5 ) tc.setPreferredWidth(10);
		else if (i==4 || i==9 ) tc.setPreferredWidth(60);
		else if (i==2 || i==6) tc.setPreferredWidth(120);
		else if (i==8) tc.setPreferredWidth(140);
		else {tc.setPreferredWidth(100);}
		}
		
		table.setAutoCreateRowSorter(true);
		
		JButton btnMents = new JButton("Ment\u00E9s");
		btnMents.setBackground(new Color(169, 169, 169));
		btnMents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dbm.Connect();
					dbm.openFile("�sszevont.txt");
					dbm.addRecordsAll();
					dbm.closeFile();
					dbm.DisConnect();
					SM("Sikeres ki�r�s! A file megtal�lhat� �sszevont.txt n�ven");
				} catch (Exception e2) {
					SM("Sikertelen k��r�s: "+e2.getMessage());
				}
			}
		});
		btnMents.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnMents.setBounds(454, 252, 85, 24);
		contentPanel.add(btnMents);
		TableRowSorter<AllTM> trs = (TableRowSorter<AllTM>)table.getRowSorter();
		trs.setSortable(0, false);
	}
	
	public void SM(String msg) {
		JOptionPane.showMessageDialog(null, msg, "�zenet", 2);
	}
}
