package Program;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;

public class ABKezeloProg extends JFrame {

	private JPanel contentPane;
	DbMethods dbm = new DbMethods();
	private TagTM ttm;
	private KonyvTM ktm;
	private AllTM atm;


	public ABKezeloProg(ChooseType chooseType) {
		super("Men�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 350);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnReg = new JButton("Driver Regisztr\u00E1l\u00E1s");
		btnReg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.Reg();
			}
		});
		btnReg.setBackground(new Color(169, 169, 169));
		btnReg.setBounds(275, 199, 185, 55);
		btnReg.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnReg.setForeground(SystemColor.desktop);
		contentPane.add(btnReg);
		
		JButton btnAllList = new JButton("Minden List\u00E1z\u00E1sa");
		btnAllList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atm = dbm.ReadAllData();
				AllList al = new AllList(ABKezeloProg.this, atm);
				al.setVisible(true);
			}
		});
		btnAllList.setForeground(Color.BLACK);
		btnAllList.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnAllList.setBackground(new Color(169, 169, 169));
		btnAllList.setBounds(10, 59, 166, 60);
		contentPane.add(btnAllList);
		
		JButton btnTagList = new JButton("Tagok List\u00E1z\u00E1sa");
		btnTagList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ttm = dbm.ReadAllDataTag();
				TagList tl = new TagList(ABKezeloProg.this, ttm);
				tl.setVisible(true);
			}
		});
		btnTagList.setForeground(Color.BLACK);
		btnTagList.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnTagList.setBackground(new Color(169, 169, 169));
		btnTagList.setBounds(186, 59, 166, 60);
		contentPane.add(btnTagList);
		
		JButton btnKonyvList = new JButton("K\u00F6nyvek List\u00E1z\u00E1sa");
		btnKonyvList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ktm = dbm.ReadAllDataKonyv();
				KonyvList kl = new KonyvList(ABKezeloProg.this, ktm);
				kl.setVisible(true);
			}
		});
		btnKonyvList.setForeground(Color.BLACK);
		btnKonyvList.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnKonyvList.setBackground(new Color(169, 169, 169));
		btnKonyvList.setBounds(360, 59, 166, 60);
		contentPane.add(btnKonyvList);
		
		JButton btnSzuro = new JButton("Sz\u0171r\u0151");
		btnSzuro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Szuro sz = new Szuro();
				sz.setVisible(true);
			}
		});
		btnSzuro.setForeground(Color.BLACK);
		btnSzuro.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSzuro.setBackground(new Color(169, 169, 169));
		btnSzuro.setBounds(185, 129, 166, 60);
		contentPane.add(btnSzuro);
		
		JButton btnTablak = new JButton("T\u00E1bl\u00E1k");
		btnTablak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.getTables();
			}
		});
		btnTablak.setForeground(Color.BLACK);
		btnTablak.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnTablak.setBackground(new Color(169, 169, 169));
		btnTablak.setBounds(360, 129, 166, 60);
		contentPane.add(btnTablak);
		
		JButton btnUjAdat = new JButton("\u00DAj Adat");
		btnUjAdat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewInsert ni = new NewInsert(ABKezeloProg.this);
				ni.setVisible(true);
			}
		});
		btnUjAdat.setForeground(Color.BLACK);
		btnUjAdat.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnUjAdat.setBackground(new Color(169, 169, 169));
		btnUjAdat.setBounds(10, 129, 166, 60);
		contentPane.add(btnUjAdat);
		
		JLabel lblNewLabel = new JLabel("Kil\u00E9p\u00E9s");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblNewLabel.setBounds(232, 286, 74, 17);
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel.setForeground(new Color(255,0,0));
				
			}
			public void mouseExited(MouseEvent e) {
				lblNewLabel.setForeground(new Color(0,0,0));
			}
			public void mouseClicked(MouseEvent arg0) {
				if(JOptionPane.showConfirmDialog(null, "Ezzel visszal�p a form�tum v�laszt�shoz. Biztos?", "Biztos?", JOptionPane.YES_NO_OPTION)==0) {
					ChooseType ct = new ChooseType(null);
					ct.setVisible(true);
					dispose();
				}
			}
		});
		contentPane.add(lblNewLabel);
		
		JLabel lblAdatbzisKezelMen = new JLabel("SQLITE Kezel\u0151 Men\u00FC");
		lblAdatbzisKezelMen.setForeground(new Color(0, 0, 0));
		lblAdatbzisKezelMen.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdatbzisKezelMen.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblAdatbzisKezelMen.setBounds(99, 10, 344, 28);
		lblAdatbzisKezelMen.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblAdatbzisKezelMen.setForeground(new Color(192,192,192));				
			}
			public void mouseExited(MouseEvent e) {
				lblAdatbzisKezelMen.setForeground(new Color(0,0,0));
			}
		});
		contentPane.add(lblAdatbzisKezelMen);
		
		JButton btnAdatokKirsaPdfbe = new JButton("Adatok ki\u00EDr\u00E1sa PDF-be");
		btnAdatokKirsaPdfbe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.DataWriteToPdf();
			}
		});
		btnAdatokKirsaPdfbe.setForeground(Color.BLACK);
		btnAdatokKirsaPdfbe.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnAdatokKirsaPdfbe.setBackground(new Color(169, 169, 169));
		btnAdatokKirsaPdfbe.setBounds(62, 199, 203, 55);
		contentPane.add(btnAdatokKirsaPdfbe);
		
		Object tagtmn[] = {"Jel","K�d","N�v","Telefonsz�m","C�m","Sz�let�si id�"};
		ttm = new TagTM(tagtmn,0);
		
		Object konyvtmn[] = {"Jel","K�d","C�m","Szerz�","Megjelen�s D�tuma","Tagok akin�l a k�nyv van"};
		ktm = new KonyvTM(konyvtmn, 0);
		
		Object alltmn[] = {"Jel","K�d","C�m","Szerz�","Megjel. D�tum","Tag ID","N�v","Telefonsz�m","C�m","Sz�l. id�"};
		atm = new AllTM(alltmn, 0);
		
	}
}
